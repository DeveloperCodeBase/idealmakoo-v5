@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Open dist\downloads\Luma-Liquid-Glass-v2.html directly, or install Node.js to use this server.
  pause
  exit /b 1
)
node server.mjs
pause
