#!/usr/bin/env python3
"""Make an offline single HTML and a clean source ZIP; only Python stdlib is used."""
from pathlib import Path
import base64
import json
import re
import zipfile
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / 'dist'
OUT = DIST / 'downloads'
OUT.mkdir(exist_ok=True)

html = (DIST / 'index.html').read_text(encoding='utf-8')
css = (DIST / 'styles.css').read_text(encoding='utf-8')
font_data = base64.b64encode((DIST / 'assets/Vazirmatn.woff2').read_bytes()).decode('ascii')
css = css.replace("url('./assets/Vazirmatn.woff2')", f"url('data:font/woff2;base64,{font_data}')")
favicon = (DIST / 'assets/favicon.svg').read_text(encoding='utf-8')
html = html.replace('href="./assets/favicon.svg"', 'href="data:image/svg+xml,' + quote(favicon, safe='') + '"')
html = re.sub(r'\s*<link rel="preload"[^>]+>', '', html)
html = html.replace('<link rel="stylesheet" href="./styles.css">', '<style>' + css + '</style>')
config = (DIST / 'config.js').read_text(encoding='utf-8')
html = html.replace('<script src="./config.js"></script>', '<script>' + config + '</script>')
modules = {name:(DIST / name).read_text(encoding='utf-8') for name in ['vendor/three.core.js','vendor/three.module.js','tooth-scene.js','auth-logic.js','app.js']}
payload = json.dumps(modules, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')
licenses = '\n\n'.join((DIST / filename).read_text(encoding='utf-8') for filename in ['vendor/THREE-LICENSE.txt', 'assets/Vazirmatn-LICENSE.txt'])
loader = r'''
<script id="luma-bundled-modules" type="application/json">__PAYLOAD__</script>
<script type="module">
// Offline module assembly: every dependency and the Persian font are in this file.
const bundled = JSON.parse(document.getElementById('luma-bundled-modules').textContent);
const moduleURLs = [];
function moduleURL(source) {
  const url = URL.createObjectURL(new Blob([source], {type:'text/javascript'}));
  moduleURLs.push(url);
  return url;
}
const core = moduleURL(bundled['vendor/three.core.js']);
const three = moduleURL(bundled['vendor/three.module.js'].replaceAll('./three.core.js', core));
const tooth = moduleURL(bundled['tooth-scene.js'].replaceAll('./vendor/three.module.js', three));
const logic = moduleURL(bundled['auth-logic.js']);
const app = moduleURL(bundled['app.js'].replaceAll('./tooth-scene.js', tooth).replaceAll('./auth-logic.js', logic));
try { await import(app); }
catch (error) {
  document.getElementById('tooth-canvas').hidden = true;
  document.getElementById('tooth-fallback').hidden = false;
  const note = document.createElement('div');
  note.className = 'noscript-note';
  note.textContent = 'اجرای این فایل در مرورگر محدود شده است. فایل را در Chrome، Edge یا Firefox باز کنید، یا نسخهٔ پوشه‌ای را با دستور npm start اجرا کنید.';
  document.body.appendChild(note);
}
window.addEventListener('pagehide', event => {
  if (!event.persisted) moduleURLs.forEach(url => URL.revokeObjectURL(url));
});
</script>
'''.replace('__PAYLOAD__', payload)
html = html.replace('<script type="module" src="./app.js"></script>', loader)
html = html.replace('</body>', '<!--\nBundled open-source license notices:\n' + licenses.replace('--', '—') + '\n-->\n</body>')
standalone = OUT / 'Luma-Liquid-Glass-v2.html'
standalone.write_text(html, encoding='utf-8')

archive = OUT / 'Luma-Liquid-Glass-v2-Source.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
  for path in sorted(ROOT.rglob('*')):
    if not path.is_file(): continue
    relative = path.relative_to(ROOT)
    if any(part in {'.git','.openai','node_modules','__pycache__'} for part in relative.parts): continue
    if path.suffix == '.log': continue
    if OUT in path.parents and path != standalone: continue
    zf.write(path, 'Luma-Dental/' + str(relative))

print(json.dumps({'standalone':str(standalone),'standalone_bytes':standalone.stat().st_size,'source_zip':str(archive),'source_zip_bytes':archive.stat().st_size}, indent=2))
