import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeEmail, validateEmail, validateForm, passwordStrength, sendAuthRequest,
} from '../dist/auth-logic.js';

const validSignup = {
  name: 'آوا رضایی', email: 'ava@example.com', password: 'لبخند۱۲۳۴', consent: true,
};
const config = {
  endpoints: {
    login: 'https://auth.example.test/login',
    register: 'https://auth.example.test/register',
    recovery: 'https://auth.example.test/recovery',
  },
  credentials: 'same-origin', timeoutMs: 1000,
};
const response = (status, data) => ({
  ok: status >= 200 && status < 300, status,
  async json() { return data; },
});

test('email edges are trimmed without changing case or the local part', () => {
  assert.equal(normalizeEmail('  Ava+appointments@Example.COM\n'), 'Ava+appointments@Example.COM');
  assert.equal(normalizeEmail('\u2002آوا@example.com\u2002'), 'آوا@example.com');
  assert.equal(validateEmail('  ava@example.com  '), '');
  assert.equal(normalizeEmail(undefined), '');
  for (const email of ['', 'a b@example.com', 'ava@@example.com', 'ava@', 'ava@example', 'a'.repeat(250) + '@example.com']) {
    assert.notEqual(validateEmail(email), '', `Reject malformed or oversized email: ${email.slice(0, 40)}`);
  }
});

test('signup accepts Persian and Latin names, letters, and number scripts', () => {
  assert.deepEqual(validateForm('signup', validSignup), {});
  assert.deepEqual(validateForm('signup', {
    ...validSignup, name: 'Ava Rezaei', password: 'Smile2026',
  }), {});
  assert.deepEqual(validateForm('signup', {
    ...validSignup, password: 'لبخند123',
  }), {});
});

test('login accepts existing short passwords and does not apply signup policy', () => {
  for (const password of ['7', 'old', 'رمز', ' with spaces ']) {
    assert.deepEqual(validateForm('login', { email: validSignup.email, password }), {}, password);
  }
  assert.ok(validateForm('login', { email: validSignup.email, password: '' }).password);
});

test('signup requires a meaningful name, eight characters, letters, numbers, and consent', () => {
  assert.ok(validateForm('signup', { ...validSignup, name: '  ' }).name);
  assert.ok(validateForm('signup', { ...validSignup, name: 'آ' }).name);
  assert.ok(validateForm('signup', { ...validSignup, consent: false }).consent);
  assert.ok(validateForm('signup', { ...validSignup, consent: undefined }).consent);
  for (const password of ['Smile12', 'abcdefgh', '۱۲۳۴۵۶۷۸', '🙂🙂🙂🙂🙂🙂🙂1']) {
    assert.ok(validateForm('signup', { ...validSignup, password }).password, password);
  }
  assert.ok(validateForm('signup', { ...validSignup, password: 'a1' + 'x'.repeat(127) }).password);
  assert.deepEqual(validateForm('signup', { ...validSignup, password: 'a1' + 'x'.repeat(126) }), {});
});

test('password length counts complete Unicode characters at the minimum boundary', () => {
  // Astral symbols have two UTF-16 code units; they must not count as two characters.
  assert.ok(validateForm('signup', { ...validSignup, password: 'a1🙂🙂🙂🙂🙂' }).password);
  assert.deepEqual(validateForm('signup', { ...validSignup, password: 'a1🙂🙂🙂🙂🙂🙂' }), {});
});

test('password strength respects the documented length and character boundaries', () => {
  const cases = [
    ['', 0], ['abc1234', 1], ['abcdefgh', 1], ['۱۲۳۴۵۶۷۸', 1],
    ['abc12345', 2], ['abc12345678', 2],
    ['abc123456789', 3], ['abc123456789012', 3],
    ['abc1234567890123', 3], ['abc123456789012!', 4],
    ['لبخند۱۲۳۴', 2],
  ];
  for (const [password, level] of cases) {
    assert.equal(passwordStrength(password).level, level, JSON.stringify(password));
  }
});

test('auth sends exactly one JSON POST and does not expose a secret in URL or logs', async (t) => {
  const consoleCalls = [];
  for (const method of ['log', 'info', 'warn', 'error', 'debug']) {
    t.mock.method(console, method, (...args) => consoleCalls.push([method, args]));
  }
  const payload = {
    name: 'آوا رضایی', email: normalizeEmail(' ava@example.com '),
    password: ' intentional spaces 123 ', acceptedTerms: true,
  };
  let observed;
  const result = await sendAuthRequest('register', payload, config, async (url, options) => {
    assert.equal(observed, undefined, 'A submission should issue one request');
    observed = { url, options };
    return response(201, { ok: true, user: { id: 'test-user' } });
  });
  assert.equal(observed.url, config.endpoints.register);
  assert.equal(observed.options.method, 'POST');
  assert.equal(observed.options.credentials, 'same-origin');
  assert.equal(observed.options.headers['Content-Type'], 'application/json');
  assert.equal(observed.options.headers.Accept, 'application/json');
  assert.deepEqual(JSON.parse(observed.options.body), payload);
  assert.ok(observed.options.signal instanceof AbortSignal);
  assert.equal(observed.url.includes(payload.password), false);
  assert.deepEqual(consoleCalls, []);
  assert.deepEqual(result, { ok: true, user: { id: 'test-user' } });
});

test('missing or non-HTTP endpoints fail before issuing a request', async () => {
  let requests = 0;
  const fetchImpl = async () => { requests += 1; return response(200, { ok: true }); };
  await assert.rejects(sendAuthRequest('login', {}, { endpoints: {} }, fetchImpl));
  for (const endpoint of ['javascript:alert(1)', 'data:text/plain,hello', 'file:///etc/hosts']) {
    await assert.rejects(sendAuthRequest('login', {}, { endpoints: { login: endpoint } }, fetchImpl));
  }
  assert.equal(requests, 0);
});

test('rate-limited responses produce actionable feedback instead of arbitrary server text', async () => {
  await assert.rejects(
    sendAuthRequest('login', {}, config, async () => response(429, { ok: false, message: 'internal gateway detail' })),
    error => /تعداد تلاش/.test(error.message) && !error.message.includes('internal'),
  );
  await assert.rejects(
    sendAuthRequest('login', {}, config, async () => ({
      ok: false, status: 429, async json() { throw new SyntaxError('Gateway returned HTML'); },
    })),
    error => /تعداد تلاش/.test(error.message),
  );
});

test('authentication errors retain a short useful server message and bound unexpected details', async () => {
  await assert.rejects(
    sendAuthRequest('login', {}, config, async () => response(401, { ok: false, message: 'ایمیل یا رمز عبور درست نیست.' })),
    { message: 'ایمیل یا رمز عبور درست نیست.' },
  );
  await assert.rejects(
    sendAuthRequest('login', {}, config, async () => response(500, { ok: false, message: 'x'.repeat(1000) })),
    error => error.message.length < 240 && !error.message.includes('xxx'),
  );
  await assert.rejects(
    sendAuthRequest('login', {}, config, async () => response(200, { ok: false, message: 'ورود تأیید نشد.' })),
    { message: 'ورود تأیید نشد.' },
  );
});

test('a 200 HTML fallback or unconfirmed JSON response cannot authenticate a user', async () => {
  await assert.rejects(sendAuthRequest('login', {}, config, async () => ({
    ok: true, status: 200, async json() { throw new SyntaxError('HTML page, not JSON'); },
  })));
  for (const body of [{}, { message: 'ok' }, { ok: 'true' }, null, []]) {
    await assert.rejects(
      sendAuthRequest('login', {}, config, async () => response(200, body)),
      `An explicit {ok:true} response is required: ${JSON.stringify(body)}`,
    );
  }
});

test('timeout aborts the pending fetch and reports a retryable timeout', async () => {
  let signal;
  await assert.rejects(sendAuthRequest('login', {}, { ...config, timeoutMs: 8 }, async (_url, options) => {
    signal = options.signal;
    return new Promise((_resolve, reject) => {
      signal.addEventListener('abort', () => reject(new DOMException('Aborted', 'AbortError')), { once: true });
    });
  }), error => /طول کشید/.test(error.message));
  assert.equal(signal.aborted, true);
});

test('timeout while reading a response body remains a timeout, not malformed JSON', async () => {
  await assert.rejects(sendAuthRequest('login', {}, { ...config, timeoutMs: 8 }, async (_url, options) => ({
    ok: true, status: 200,
    json: () => new Promise((_resolve, reject) => {
      options.signal.addEventListener('abort', () => reject(new DOMException('Aborted body', 'AbortError')), { once: true });
    }),
  })), error => /طول کشید/.test(error.message));
});

test('successful requests clear their timeout instead of later aborting completed work', async () => {
  let signal;
  await sendAuthRequest('login', {}, { ...config, timeoutMs: 10 }, async (_url, options) => {
    signal = options.signal;
    return response(200, { ok: true });
  });
  await new Promise(resolve => setTimeout(resolve, 20));
  assert.equal(signal.aborted, false);
});

test('network errors use a safe retry message without printing fetch internals', async () => {
  await assert.rejects(sendAuthRequest('login', { password: 'never-print-this' }, config, async () => {
    throw new TypeError('Network failure with sensitive internal diagnostics');
  }), error => /ارتباط/.test(error.message) && !error.message.includes('sensitive'));
});
